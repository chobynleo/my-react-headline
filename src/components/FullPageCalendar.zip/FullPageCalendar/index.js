/**
 * Created by laishuliang on 2018/7/18.
 */

import FullPageCalendar from './FullPageCalendar';

export default FullPageCalendar;