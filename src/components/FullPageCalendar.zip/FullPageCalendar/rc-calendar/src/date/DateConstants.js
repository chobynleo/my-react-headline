export default {
  DATE_ROW_COUNT: 6,
  DATE_COL_COUNT: 7,
};
