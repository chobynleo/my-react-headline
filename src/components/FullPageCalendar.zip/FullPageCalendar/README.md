# 日期（节假日）管理组件 FullPageCalendar


本组件是对组件基于rc-calendar封装，虽直接引入了rc-calendar的源码，当目前没有对`/rc-calendar`目录下的源码作改动，但为了减少档案体积，删减了
部分没有引用到的文件及目录。
组件样式定义及修改请转到`/rc-calendar/assets`目录，为便于查找和以后升级，有更改的样式作了`// {edit}`标记。


## 何时使用

适用于平铺展示全年日期并设置节假日日期的场景。。

## 组件 API

| 参数                       | 说明                                                                                                                                                                                                        | 类型              | 默认值                 |
| :------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------- | :--------------------- |
| lunarVisible            | 默认是否展示农历                                                                                                                                                                                            | boolean            | true                      |
| selectedYear               | 默认展示的年份                                                                                                                                                                                                | number             | now.year()，当前年                      |
| fomatter            | 日期格式化格式                                                                                                                                | string            | 'YYYY-MM-DD'                      |
| excludeTypes | 节假日类型                                                                                 | Array            | -                      |
| showRangeYear           | (切换)年份区间，前后多少年                                                     | array             | -          |
| allSelectedDate    | 初始化设置日期 | object             | -                      |
| allInOneSave    | 单次提交配置 | object             | -                      |
| onYearSelect    | 切换年回调，可动态获取年数据 | object             | -                      |
| onSave    | 提交回调，根据allInOneSave配置是单次还是一次提交 | object             | -                      |
| onDel    | 删除回调 | object             | -                      |


## 示例代码

```
// 所有例外时间 -- 以类型组织
const allSelectedDate = {
  offday: ['2018-1-1', '2018-6-18', '2018-9-24'],
  reday: ['2018-4-8', '2018-4-28', '2018-9-29', '2018-9-30'],
  yuandan: ['2018-1-1'],
  chunjie: ['2018-2-15', '2018-2-16', '2018-2-17', '2018-2-18', '2018-2-19', '2018-2-20', '2018-2-21'],
  qingming: ['2018-4-5', '2018-4-6', '2018-4-7'],
  laodong: ['2018-4-29', '2018-4-30', '2018-5-1'],
  duanwu: ['2018-6-16', '2018-6-17', '2018-6-18'],
  zhongqiu: ['2018-9-22', '2018-9-23', '2018-9-24'],
  guoqing: ['2018-10-1', '2018-10-2', '2018-10-3', '2018-10-4', '2018-10-5', '2018-10-6', '2018-10-7']
};

const excludeTypeData = [
  {
    label: '调休日',
    value: 'offday',
    badge: true,
    badgeLabel: '休'
  },
  {
    label: '补班日',
    value: 'reday',
    badge: true,
    badgeLabel: '班',
    badgeStyle: {
      backgroundColor: '#4A4A4A'
    }
  },
  {
    label: '节假日',
    value: 'holiday',
    color: 'blue',
    icon: 'smile-o',
    children: [
      { label: '元旦', value: 'yuandan', color: 'blue', icon: 'smile-o' },
      { label: '春节', value: 'chunjie', color: '#FF0080', icon: 'heart-o' },
      { label: '清明', value: 'qingming', color: '#8E8E8E', icon: 'medicine-box' },
      { label: '劳动', value: 'laodong', color: '#7CFC00', icon: 'frown-o' },
      { label: '端午', value: 'duanwu', color: 'blue' },
      { label: '中秋', value: 'zhongqiu', color: '#458B00', icon: 'gift' },
      { label: '国庆', value: 'guoqing', color: '#820041', icon: 'car' }
    ]
  }
];

const fomatter = 'YYYY-MM-DD';


class FullPageCalendarTestPage extends Component {
  onYearSelect = (data) => {
    console.info('调试输出 onYearSelect data:', data);
  };

  onSave = (data) => {
    console.info('调试输出 onSave data:', data);
  };

  onDel = (data) => {
    console.info('调试输出 onDel data:', data);
  };

  render() {
    return (
      <div className={styles.pageContainer}>
        <FullPageCalendar
          lunarVisible
          fomatter={fomatter}
          allSelectedDate={allSelectedDate}
          excludeTypes={excludeTypeData}
          selectedYear={2018}
          showRangeYear={[4, 7]}
          allInOneSave={false}
          onYearSelect={this.onYearSelect}
          onSave={this.onSave}
          onDel={this.onDel}
        />;
      </div>);
  }
}
```

## 更新日志

=======FullPageCalendar组件 - 2018.7.17修改记录（1）=======
1.初次提交，实现基本功能；

=======FullPageCalendar组件 - 2018.7.25修改记录（2）=======
1.日期类型，可根据数据源多级展示联动选择，第一级类型少于等于3个项时平铺展示，大于3项自动切换为下拉选择；
2.新增角标提示类型，可在数据源中配置，可设置角标文字和样式，默认右上角，绿色阴影显示；
3.新增单次选择提交和allInOne一次提交配置，可切换提交类型，如配置为单次提交，保存按钮不出现；
4.新增如当某日期被选择为节假日，不显示农历，角标类型除外；
5.界面美化，缩小了月历框和行高；
